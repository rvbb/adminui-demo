/**
 * @license
 * Copyright Viettel Digital Corps. All Rights Reserved.
 */

declare var module: NodeModule;
interface NodeModule {
  id: string;
}

declare var tinymce: any;

declare var echarts: any;

import { Injectable } from '@angular/core';

@Injectable()
export class GeneralService {
    // implement method to process data
}
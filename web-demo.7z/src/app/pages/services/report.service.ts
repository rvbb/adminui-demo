import { Injectable } from '@angular/core';

@Injectable()
export class ReportService {
    // implement method to process data
}
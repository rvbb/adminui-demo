import { Component } from '@angular/core';

@Component({
  selector: 'bankplus',
  template: `
    <router-outlet></router-outlet>    
  `,
})
export class PagesComponent {

  ngOnInit() {
   
  }
}

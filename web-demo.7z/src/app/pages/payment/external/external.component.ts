import { Component } from '@angular/core';

@Component({
  selector: 'payment-external',
  styleUrls: ['./external.component.scss'],
  templateUrl: './external.component.html',
})
export class ExternalComponent {

}

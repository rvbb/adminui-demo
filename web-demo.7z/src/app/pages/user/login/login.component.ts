import { Component } from '@angular/core';

@Component({
  selector: 'user-login',
  styleUrls: ['./login.component.scss'],
  templateUrl: './login.component.html',
})

export class LoginComponent {
}

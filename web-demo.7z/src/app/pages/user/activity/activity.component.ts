import { Component } from '@angular/core';

@Component({
  selector: 'user-activity',
  styleUrls: ['./activity.component.scss'],
  templateUrl: './activity.component.html',
})

export class ActivityComponent {
}

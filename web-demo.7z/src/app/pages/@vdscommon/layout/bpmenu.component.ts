import { Component } from '@angular/core';

@Component({
  selector: 'bpmenu',
  templateUrl: "./bpmenu.component.html",
  styleUrls: ['./bpmenu.component.scss']
})
export class BpmenuComponent {

}

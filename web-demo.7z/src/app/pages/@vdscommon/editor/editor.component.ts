import { Component } from '@angular/core';
import './editor.loader';
import 'ckeditor';

@Component({
  selector: 'ngx-ckeditor',
  templateUrl: "editor.component.html"
})
export class EditorComponent {

}

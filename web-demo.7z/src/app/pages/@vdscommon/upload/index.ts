export * from './upload.component';

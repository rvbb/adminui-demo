import { Component } from '@angular/core';

@Component({
  selector: 'vds-report',
  template: `<router-outlet></router-outlet>`,
})
export class ReportComponent {
}

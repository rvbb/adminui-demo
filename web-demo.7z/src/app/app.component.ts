/**
 * @license
 * Copyright Viettel Digital Corps. All Rights Reserved.
 */
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'bankplus-app',
  template: '<router-outlet></router-outlet>',
})
export class AppComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }
}
